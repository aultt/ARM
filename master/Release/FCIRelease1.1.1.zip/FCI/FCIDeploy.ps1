Login-AzureRmAccount
Select-AzureRmSubscription -SubscriptionName TAMZ_SandBox

$RG = 'sqlfci06'
New-AzureRmResourceGroup -Name $RG -Location "East US"
Set-Location 'C:\Users\troyault.TAMZ\OneDrive - TAMZ\Git\ARM\FCI'
New-AzureRmResourceGroupDeployment -Name NewFCI -ResourceGroupName $RG -TemplateFile azuredeploy.json -TemplateParameterFile azuredeploy.parameters.json -Verbose

Remove-AzureRmResourceGroup -Name $RG -Force
get-adcomputer -property Name -filter {name -like 'aesql100*'} | Remove-ADComputer 
